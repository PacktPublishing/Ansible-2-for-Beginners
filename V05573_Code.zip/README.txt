V05573 - Ansible 2 for Beginners

*Code Requirement*

The Code for Section 3, 4 & 5 is presnt.

However, code for section 1, 2 & 6 is not.